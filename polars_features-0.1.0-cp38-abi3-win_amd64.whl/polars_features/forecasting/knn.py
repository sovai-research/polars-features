from __future__ import annotations

from typing import Optional

import polars as pl

from polars_features.base import Forecaster
from polars_features.forecasting._ar import fit_autoreg
from polars_features.forecasting._regressors import SklearnRegressor


def _knn(**kwargs):
    def regress(X: pl.DataFrame, y: pl.DataFrame):
        from sklearn.neighbors import KNeighborsRegressor

        regressor = SklearnRegressor(
            regressor=KNeighborsRegressor(**kwargs, n_jobs=-1),
        )
        return regressor.fit(X=X, y=y)

    return regress


class knn(Forecaster):
    """Autoregressive k-nearest neighbors."""

    def _fit(self, y: pl.LazyFrame, X: Optional[pl.LazyFrame] = None):
        regress = _knn(**self.kwargs)
        return fit_autoreg(
            regress=regress,
            y=y,
            X=X,
            lags=self.lags,
            max_horizons=self.max_horizons,
            strategy=self.strategy,
        )
